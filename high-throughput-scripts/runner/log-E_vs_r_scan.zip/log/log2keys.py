import os
import glob

keys = []
values = []

for logfile in glob.iglob(os.path.join(os.getcwd(), '*.log')):
    first = True
    with open(logfile) as f:
        for line in f:
            terms = line.split()
            if len(terms) > 0:
                if len(terms) == 1 and len(terms[0]) == 36:
                    keys.append(terms[0])
                    if not first:
                        values.append(value)
                    else:
                        first = False
                    value = ''
                else:
                    value += line
    values.append(value)
print len(keys)  
print len(values)
keyset = set(keys)
with open('keys.txt', 'w') as f:
    f.write('\n'.join(keyset))
print len(keyset)

for i in xrange(len(keys)):
    if keys[i] in keys[i+1:]:
        j = keys[i+1:].index(keys[i])
        print keys[i]
        print values[i]
        print values[i+j+1]
        print
        